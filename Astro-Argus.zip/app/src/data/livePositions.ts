import type { Planet, House, Aspect } from '@/types/astro';

// More accurate planetary calculations based on orbital elements
// Using simplified ephemeris calculations

interface OrbitalElements {
  meanLongitude: number;  // degrees at J2000.0
  dailyMotion: number;    // degrees per day
  eccentricity: number;
  inclination: number;
}

// Orbital elements for planets (simplified)
const PLANET_ORBITS: Record<string, OrbitalElements> = {
  sun: {
    meanLongitude: 280.46646,
    dailyMotion: 0.98564736,
    eccentricity: 0.016708,
    inclination: 0
  },
  moon: {
    meanLongitude: 218.316,
    dailyMotion: 13.176396,
    eccentricity: 0.0549,
    inclination: 5.145
  },
  mercury: {
    meanLongitude: 252.251,
    dailyMotion: 4.092338,
    eccentricity: 0.20563,
    inclination: 7.005
  },
  venus: {
    meanLongitude: 181.979,
    dailyMotion: 1.602130,
    eccentricity: 0.00677,
    inclination: 3.3947
  },
  mars: {
    meanLongitude: 355.433,
    dailyMotion: 0.524039,
    eccentricity: 0.0934,
    inclination: 1.85
  },
  jupiter: {
    meanLongitude: 34.351,
    dailyMotion: 0.083056,
    eccentricity: 0.0489,
    inclination: 1.305
  },
  saturn: {
    meanLongitude: 50.077,
    dailyMotion: 0.033371,
    eccentricity: 0.0565,
    inclination: 2.484
  },
  uranus: {
    meanLongitude: 314.055,
    dailyMotion: 0.011698,
    eccentricity: 0.0457,
    inclination: 0.772
  },
  neptune: {
    meanLongitude: 304.349,
    dailyMotion: 0.005965,
    eccentricity: 0.0113,
    inclination: 1.769
  },
  pluto: {
    meanLongitude: 238.929,
    dailyMotion: 0.003964,
    eccentricity: 0.2488,
    inclination: 17.16
  }
};

// J2000.0 epoch
const J2000 = new Date('2000-01-01T12:00:00Z');

// Calculate days since J2000.0
function getDaysSinceJ2000(date: Date): number {
  return (date.getTime() - J2000.getTime()) / (1000 * 60 * 60 * 24);
}

// Calculate planet position
function calculatePlanetPosition(planet: string, date: Date): number {
  const orbit = PLANET_ORBITS[planet];
  if (!orbit) return 0;

  const days = getDaysSinceJ2000(date);
  let longitude = orbit.meanLongitude + orbit.dailyMotion * days;
  
  // Normalize to 0-360
  longitude = ((longitude % 360) + 360) % 360;
  
  return longitude;
}

// Determine if planet is retrograde (simplified)
function isRetrograde(planet: string, date: Date): boolean {
  if (['sun', 'moon'].includes(planet)) return false;
  
  const orbit = PLANET_ORBITS[planet];
  if (!orbit) return false;
  
  const days = getDaysSinceJ2000(date);
  
  // Retrograde periods occur at specific intervals
  // This is a simplified approximation
  const retrogradeCycles: Record<string, { period: number; duration: number; offset: number }> = {
    mercury: { period: 116, duration: 21, offset: 0 },
    venus: { period: 584, duration: 42, offset: 100 },
    mars: { period: 780, duration: 72, offset: 200 },
    jupiter: { period: 399, duration: 121, offset: 50 },
    saturn: { period: 378, duration: 138, offset: 150 },
    uranus: { period: 370, duration: 151, offset: 300 },
    neptune: { period: 367, duration: 158, offset: 400 },
    pluto: { period: 366, duration: 160, offset: 500 }
  };
  
  const cycle = retrogradeCycles[planet];
  if (!cycle) return false;
  
  const cyclePosition = (days + cycle.offset) % cycle.period;
  return cyclePosition < cycle.duration;
}

// Get planet symbol
function getPlanetSymbol(name: string): string {
  const symbols: Record<string, string> = {
    sun: '☉', moon: '☽', mercury: '☿', venus: '♀', mars: '♂',
    jupiter: '♃', saturn: '♄', uranus: '♅', neptune: '♆', pluto: '♇',
    northNode: '☊', southNode: '☋', ascendant: 'ASC', mc: 'MC'
  };
  return symbols[name] || '●';
}

// Get planet color
function getPlanetColor(name: string): string {
  const colors: Record<string, string> = {
    sun: '#fbbf24', moon: '#e2e8f0', mercury: '#a855f7', venus: '#ec4899',
    mars: '#ef4444', jupiter: '#f97316', saturn: '#64748b', uranus: '#06b6d4',
    neptune: '#3b82f6', pluto: '#7c3aed', northNode: '#fbbf24',
    southNode: '#94a3b8', ascendant: '#22c55e', mc: '#eab308'
  };
  return colors[name] || '#94a3b8';
}

// Calculate houses using Placidus system (simplified)
function calculateHouses(date: Date, _latitude: number = 40.7128, _longitude: number = -74.0060): House[] {
  // Simplified house calculation
  // In a real app, this would use proper astronomical calculations
  const sunPos = calculatePlanetPosition('sun', date);
  const ascendantOffset = (sunPos + 180) % 360;
  
  const houses: House[] = [];
  for (let i = 0; i < 12; i++) {
    const cuspDegree = (ascendantOffset + i * 30) % 360;
    houses.push({
      number: i + 1,
      cuspDegree,
      sign: Math.floor(cuspDegree / 30)
    });
  }
  return houses;
}

// Calculate aspects between planets
function calculateAspects(planets: Planet[]): Aspect[] {
  const aspects: Aspect[] = [];
  const aspectAngles: Record<string, number> = {
    conjunction: 0,
    sextile: 60,
    square: 90,
    trine: 120,
    opposition: 180
  };
  
  const orb = 8; // 8 degree orb
  
  for (let i = 0; i < planets.length; i++) {
    for (let j = i + 1; j < planets.length; j++) {
      const p1 = planets[i];
      const p2 = planets[j];
      
      // Skip nodes and points for aspects
      if (['northNode', 'southNode', 'ascendant', 'mc'].includes(p1.id)) continue;
      if (['northNode', 'southNode', 'ascendant', 'mc'].includes(p2.id)) continue;
      
      const diff = Math.abs(p1.degree - p2.degree);
      const angle = Math.min(diff, 360 - diff);
      
      for (const [type, targetAngle] of Object.entries(aspectAngles)) {
        if (Math.abs(angle - targetAngle) <= orb) {
          aspects.push({
            planet1: p1.id,
            planet2: p2.id,
            type: type as Aspect['type'],
            orb: Math.abs(angle - targetAngle),
            angle
          });
        }
      }
    }
  }
  
  return aspects;
}

// Generate live planetary positions
export function generateLivePositions(date: Date = new Date()): Planet[] {
  const planets: Planet[] = [
    {
      id: 'sun',
      name: 'Sun',
      symbol: getPlanetSymbol('sun'),
      degree: calculatePlanetPosition('sun', date),
      sign: 0,
      signDegree: 0,
      color: getPlanetColor('sun')
    },
    {
      id: 'moon',
      name: 'Moon',
      symbol: getPlanetSymbol('moon'),
      degree: calculatePlanetPosition('moon', date),
      sign: 0,
      signDegree: 0,
      color: getPlanetColor('moon')
    },
    {
      id: 'mercury',
      name: 'Mercury',
      symbol: getPlanetSymbol('mercury'),
      degree: calculatePlanetPosition('mercury', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('mercury', date),
      color: getPlanetColor('mercury')
    },
    {
      id: 'venus',
      name: 'Venus',
      symbol: getPlanetSymbol('venus'),
      degree: calculatePlanetPosition('venus', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('venus', date),
      color: getPlanetColor('venus')
    },
    {
      id: 'mars',
      name: 'Mars',
      symbol: getPlanetSymbol('mars'),
      degree: calculatePlanetPosition('mars', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('mars', date),
      color: getPlanetColor('mars')
    },
    {
      id: 'jupiter',
      name: 'Jupiter',
      symbol: getPlanetSymbol('jupiter'),
      degree: calculatePlanetPosition('jupiter', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('jupiter', date),
      color: getPlanetColor('jupiter')
    },
    {
      id: 'saturn',
      name: 'Saturn',
      symbol: getPlanetSymbol('saturn'),
      degree: calculatePlanetPosition('saturn', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('saturn', date),
      color: getPlanetColor('saturn')
    },
    {
      id: 'uranus',
      name: 'Uranus',
      symbol: getPlanetSymbol('uranus'),
      degree: calculatePlanetPosition('uranus', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('uranus', date),
      color: getPlanetColor('uranus')
    },
    {
      id: 'neptune',
      name: 'Neptune',
      symbol: getPlanetSymbol('neptune'),
      degree: calculatePlanetPosition('neptune', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('neptune', date),
      color: getPlanetColor('neptune')
    },
    {
      id: 'pluto',
      name: 'Pluto',
      symbol: getPlanetSymbol('pluto'),
      degree: calculatePlanetPosition('pluto', date),
      sign: 0,
      signDegree: 0,
      retrograde: isRetrograde('pluto', date),
      color: getPlanetColor('pluto')
    },
    {
      id: 'northNode',
      name: 'North Node',
      symbol: getPlanetSymbol('northNode'),
      degree: (calculatePlanetPosition('moon', date) + 180) % 360,
      sign: 0,
      signDegree: 0,
      color: getPlanetColor('northNode')
    },
    {
      id: 'ascendant',
      name: 'Ascendant',
      symbol: getPlanetSymbol('ascendant'),
      degree: (calculatePlanetPosition('sun', date) + 180 + 15) % 360,
      sign: 0,
      signDegree: 0,
      color: getPlanetColor('ascendant')
    },
    {
      id: 'mc',
      name: 'Midheaven',
      symbol: getPlanetSymbol('mc'),
      degree: (calculatePlanetPosition('sun', date) + 90) % 360,
      sign: 0,
      signDegree: 0,
      color: getPlanetColor('mc')
    }
  ];
  
  return planets;
}

// Generate complete live chart data
export function generateLiveChartData(date: Date = new Date()) {
  const planets = generateLivePositions(date);
  const houses = calculateHouses(date);
  const aspects = calculateAspects(planets);
  
  return { planets, houses, aspects };
}
