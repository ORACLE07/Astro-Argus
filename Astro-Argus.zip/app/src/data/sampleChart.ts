import type { Planet, House, Aspect } from '@/types/astro';

// Sample natal chart data (example: approximate positions)
export const samplePlanets: Planet[] = [
  { id: 'sun', name: 'Sun', symbol: '☉', degree: 15.5, sign: 0, signDegree: 15.5, color: '#fbbf24' },
  { id: 'moon', name: 'Moon', symbol: '☽', degree: 82.3, sign: 2, signDegree: 22.3, color: '#e2e8f0' },
  { id: 'mercury', name: 'Mercury', symbol: '☿', degree: 8.2, sign: 0, signDegree: 8.2, retrograde: true, color: '#a855f7' },
  { id: 'venus', name: 'Venus', symbol: '♀', degree: 45.8, sign: 1, signDegree: 15.8, color: '#ec4899' },
  { id: 'mars', name: 'Mars', symbol: '♂', degree: 125.4, sign: 4, signDegree: 5.4, color: '#ef4444' },
  { id: 'jupiter', name: 'Jupiter', symbol: '♃', degree: 195.2, sign: 6, signDegree: 15.2, color: '#f97316' },
  { id: 'saturn', name: 'Saturn', symbol: '♄', degree: 298.7, sign: 9, signDegree: 28.7, retrograde: true, color: '#64748b' },
  { id: 'uranus', name: 'Uranus', symbol: '♅', degree: 45.2, sign: 1, signDegree: 15.2, color: '#06b6d4' },
  { id: 'neptune', name: 'Neptune', symbol: '♆', degree: 350.8, sign: 11, signDegree: 20.8, color: '#3b82f6' },
  { id: 'pluto', name: 'Pluto', symbol: '♇', degree: 285.3, sign: 9, signDegree: 15.3, retrograde: true, color: '#7c3aed' },
  { id: 'northNode', name: 'North Node', symbol: '☊', degree: 165.6, sign: 5, signDegree: 15.6, color: '#fbbf24' },
  { id: 'ascendant', name: 'Ascendant', symbol: 'ASC', degree: 185.0, sign: 6, signDegree: 5.0, color: '#22c55e' },
  { id: 'mc', name: 'Midheaven', symbol: 'MC', degree: 95.0, sign: 3, signDegree: 5.0, color: '#eab308' },
];

export const sampleHouses: House[] = [
  { number: 1, cuspDegree: 185.0, sign: 6 },
  { number: 2, cuspDegree: 215.0, sign: 7 },
  { number: 3, cuspDegree: 245.0, sign: 8 },
  { number: 4, cuspDegree: 275.0, sign: 9 },
  { number: 5, cuspDegree: 305.0, sign: 10 },
  { number: 6, cuspDegree: 335.0, sign: 11 },
  { number: 7, cuspDegree: 5.0, sign: 0 },
  { number: 8, cuspDegree: 35.0, sign: 1 },
  { number: 9, cuspDegree: 65.0, sign: 2 },
  { number: 10, cuspDegree: 95.0, sign: 3 },
  { number: 11, cuspDegree: 125.0, sign: 4 },
  { number: 12, cuspDegree: 155.0, sign: 5 },
];

export const sampleAspects: Aspect[] = [
  { planet1: 'sun', planet2: 'moon', type: 'sextile', orb: 3.2, angle: 66.8 },
  { planet1: 'sun', planet2: 'mars', type: 'trine', orb: 5.1, angle: 109.9 },
  { planet1: 'moon', planet2: 'saturn', type: 'opposition', orb: 3.6, angle: 183.6 },
  { planet1: 'venus', planet2: 'uranus', type: 'conjunction', orb: 0.6, angle: 0.6 },
  { planet1: 'mercury', planet2: 'jupiter', type: 'opposition', orb: 3.0, angle: 177.0 },
  { planet1: 'mars', planet2: 'pluto', type: 'square', orb: 4.1, angle: 159.9 },
  { planet1: 'jupiter', planet2: 'neptune', type: 'trine', orb: 4.4, angle: 115.6 },
  { planet1: 'saturn', planet2: 'pluto', type: 'conjunction', orb: 13.4, angle: 13.4 },
];

// Function to generate current planetary positions (simplified)
export function generateCurrentPositions(date: Date = new Date()): Planet[] {
  // This is a simplified calculation - real ephemeris calculations are complex
  const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  const yearProgress = dayOfYear / 365.25;
  
  // Approximate orbital periods and starting positions
  const orbitalPeriods: Record<string, number> = {
    sun: 365.25,
    moon: 27.32,
    mercury: 87.97,
    venus: 224.7,
    mars: 686.98,
    jupiter: 4332.59,
    saturn: 10759.22,
    uranus: 30688.5,
    neptune: 60182,
    pluto: 90580,
  };

  const basePositions: Record<string, number> = {
    sun: 0,
    moon: 45,
    mercury: 15,
    venus: 30,
    mars: 60,
    jupiter: 120,
    saturn: 180,
    uranus: 45,
    neptune: 330,
    pluto: 270,
  };

  return Object.entries(orbitalPeriods).map(([name, period]) => ({
    id: name,
    name: name.charAt(0).toUpperCase() + name.slice(1),
    symbol: getPlanetSymbol(name),
    degree: (basePositions[name] + (yearProgress * 360 / period) * 365.25) % 360,
    sign: 0,
    signDegree: 0,
    retrograde: ['mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'].includes(name) && Math.random() > 0.7,
    color: getPlanetColor(name),
  }));
}

function getPlanetSymbol(name: string): string {
  const symbols: Record<string, string> = {
    sun: '☉', moon: '☽', mercury: '☿', venus: '♀', mars: '♂',
    jupiter: '♃', saturn: '♄', uranus: '♅', neptune: '♆', pluto: '♇',
  };
  return symbols[name] || '●';
}

function getPlanetColor(name: string): string {
  const colors: Record<string, string> = {
    sun: '#fbbf24', moon: '#e2e8f0', mercury: '#a855f7', venus: '#ec4899',
    mars: '#ef4444', jupiter: '#f97316', saturn: '#64748b', uranus: '#06b6d4',
    neptune: '#3b82f6', pluto: '#7c3aed',
  };
  return colors[name] || '#94a3b8';
}
