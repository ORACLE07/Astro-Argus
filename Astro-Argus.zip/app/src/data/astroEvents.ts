export interface AstroEvent {
  id: string;
  date: string;
  title: string;
  description: string;
  planets: string[];
  aspect: string;
  marketImpact: {
    sp500Change: number;
    nasdaqChange: number;
    dowChange: number;
    summary: string;
  };
  significance: 'high' | 'medium' | 'low';
}

export const majorAstroEvents: AstroEvent[] = [
  {
    id: '1',
    date: '2020-03-21',
    title: 'Saturn enters Aquarius',
    description: 'Saturn moves into Aquarius, beginning a new 2.5-year cycle. This coincided with the start of global lockdowns.',
    planets: ['Saturn'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: -4.34,
      nasdaqChange: -3.79,
      dowChange: -4.55,
      summary: 'Market crash - S&P 500 dropped 34% from Feb highs. COVID-19 pandemic began disrupting global markets.'
    },
    significance: 'high'
  },
  {
    id: '2',
    date: '2020-12-21',
    title: 'Great Conjunction - Jupiter-Saturn in Aquarius',
    description: 'Jupiter and Saturn conjunct at 0° Aquarius, marking the beginning of a new 200-year air cycle.',
    planets: ['Jupiter', 'Saturn'],
    aspect: 'Conjunction',
    marketImpact: {
      sp500Change: 0.47,
      nasdaqChange: 0.74,
      dowChange: 0.12,
      summary: 'Markets rallied to new highs. Vaccine approvals boosted investor confidence. Tech stocks surged.'
    },
    significance: 'high'
  },
  {
    id: '3',
    date: '2021-05-13',
    title: 'Jupiter enters Pisces',
    description: 'Jupiter enters its home sign Pisces, expanding themes of spirituality, compassion, and speculation.',
    planets: ['Jupiter'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: -1.65,
      nasdaqChange: -2.67,
      dowChange: -0.66,
      summary: 'Tech sell-off continued. Inflation concerns rose. Crypto markets experienced volatility.'
    },
    significance: 'medium'
  },
  {
    id: '4',
    date: '2021-12-28',
    title: 'Venus Retrograde in Capricorn',
    description: 'Venus begins retrograde motion in Capricorn, revisiting themes of values, money, and relationships.',
    planets: ['Venus'],
    aspect: 'Retrograde',
    marketImpact: {
      sp500Change: -0.10,
      nasdaqChange: -0.56,
      dowChange: 0.26,
      summary: 'Markets were choppy. Omicron variant concerns weighed on sentiment. Value stocks outperformed growth.'
    },
    significance: 'medium'
  },
  {
    id: '5',
    date: '2022-01-14',
    title: 'Mercury Retrograde in Aquarius',
    description: 'First Mercury retrograde of 2022 in Aquarius, affecting technology and communication sectors.',
    planets: ['Mercury'],
    aspect: 'Retrograde',
    marketImpact: {
      sp500Change: -0.41,
      nasdaqChange: -0.58,
      dowChange: -0.56,
      summary: 'Tech stocks declined. Fed rate hike expectations put pressure on growth stocks.'
    },
    significance: 'low'
  },
  {
    id: '6',
    date: '2022-04-12',
    title: 'Jupiter conjunct Neptune in Pisces',
    description: 'Rare conjunction of Jupiter and Neptune in Pisces, last occurred in 1856. Highly speculative energy.',
    planets: ['Jupiter', 'Neptune'],
    aspect: 'Conjunction',
    marketImpact: {
      sp500Change: -0.34,
      nasdaqChange: -0.30,
      dowChange: -0.26,
      summary: 'Inflation at 40-year high. Markets braced for aggressive Fed tightening. Crypto bubble burst began.'
    },
    significance: 'high'
  },
  {
    id: '7',
    date: '2022-10-30',
    title: 'Mars Retrograde in Gemini',
    description: 'Mars begins retrograde in Gemini, affecting communication, markets, and decision-making.',
    planets: ['Mars'],
    aspect: 'Retrograde',
    marketImpact: {
      sp500Change: 2.46,
      nasdaqChange: 2.87,
      dowChange: 2.58,
      summary: 'Bear market rally. Markets anticipated Fed pivot. Tech stocks bounced from lows.'
    },
    significance: 'medium'
  },
  {
    id: '8',
    date: '2023-03-07',
    title: 'Saturn enters Pisces',
    description: 'Saturn moves into Pisces for a 2.5-year stay, bringing structure to dreams and dissolving illusions.',
    planets: ['Saturn'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: -1.53,
      nasdaqChange: -1.96,
      dowChange: -1.72,
      summary: 'Banking crisis fears emerged with SVB collapse. Fed continued rate hikes. Regional banks sold off.'
    },
    significance: 'high'
  },
  {
    id: '9',
    date: '2023-05-16',
    title: 'Jupiter enters Taurus',
    description: 'Jupiter enters Taurus, bringing expansion to finance, resources, and material security.',
    planets: ['Jupiter'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: 0.30,
      nasdaqChange: 0.28,
      dowChange: 0.14,
      summary: 'AI boom began with NVIDIA surge. Markets rallied despite debt ceiling concerns.'
    },
    significance: 'medium'
  },
  {
    id: '10',
    date: '2023-08-23',
    title: 'Sun-Mars conjunction in Leo',
    description: 'Sun and Mars conjunct in Leo, creating bold, aggressive energy in markets.',
    planets: ['Sun', 'Mars'],
    aspect: 'Conjunction',
    marketImpact: {
      sp500Change: -1.35,
      nasdaqChange: -1.87,
      dowChange: -0.84,
      summary: 'Fitch downgraded US credit rating. Bond yields surged. Tech stocks sold off on rate concerns.'
    },
    significance: 'medium'
  },
  {
    id: '11',
    date: '2023-12-13',
    title: 'Mercury Retrograde in Capricorn',
    description: 'Mercury retrograde in Capricorn during Fed meeting, communication challenges with authority.',
    planets: ['Mercury'],
    aspect: 'Retrograde',
    marketImpact: {
      sp500Change: 1.37,
      nasdaqChange: 1.38,
      dowChange: 1.40,
      summary: 'Fed signaled rate cuts coming in 2024. Markets surged to new highs. Powell pivot celebrated.'
    },
    significance: 'medium'
  },
  {
    id: '12',
    date: '2024-04-08',
    title: 'Total Solar Eclipse in Aries',
    description: 'Total solar eclipse at 19° Aries, triggering cardinal energy and new beginnings.',
    planets: ['Sun', 'Moon'],
    aspect: 'Conjunction (Eclipse)',
    marketImpact: {
      sp500Change: -0.72,
      nasdaqChange: -1.00,
      dowChange: -0.94,
      summary: 'CPI data showed sticky inflation. Rate cut expectations pushed back. Markets declined.'
    },
    significance: 'high'
  },
  {
    id: '13',
    date: '2024-05-25',
    title: 'Jupiter enters Gemini',
    description: 'Jupiter moves into Gemini for a 1-year stay, expanding communication and technology.',
    planets: ['Jupiter'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: 0.03,
      nasdaqChange: -0.10,
      dowChange: 0.01,
      summary: 'Markets near all-time highs. AI enthusiasm continued. Meme stocks resurgence.'
    },
    significance: 'medium'
  },
  {
    id: '14',
    date: '2024-08-19',
    title: 'Jupiter square Saturn',
    description: 'Jupiter in Gemini squares Saturn in Pisces, tension between expansion and restriction.',
    planets: ['Jupiter', 'Saturn'],
    aspect: 'Square',
    marketImpact: {
      sp500Change: -0.32,
      nasdaqChange: -0.85,
      dowChange: 0.58,
      summary: 'Yen carry trade unwind caused volatility. Recession fears briefly spiked. Markets recovered.'
    },
    significance: 'high'
  },
  {
    id: '15',
    date: '2024-11-01',
    title: 'Saturn stations Direct in Pisces',
    description: 'Saturn stations direct after months of retrograde, forward momentum in restructuring.',
    planets: ['Saturn'],
    aspect: 'Station Direct',
    marketImpact: {
      sp500Change: 0.41,
      nasdaqChange: 0.83,
      dowChange: 0.69,
      summary: 'Post-election rally. Fed cut rates. Tech stocks surged. New market highs achieved.'
    },
    significance: 'medium'
  },
  {
    id: '16',
    date: '2025-01-29',
    title: 'Uranus stations Direct in Taurus',
    description: 'Uranus stations direct in Taurus, sudden changes in finance and values sector.',
    planets: ['Uranus'],
    aspect: 'Station Direct',
    marketImpact: {
      sp500Change: -0.47,
      nasdaqChange: -0.51,
      dowChange: -0.31,
      summary: 'DeepSeek AI news shocked tech sector. NVIDIA dropped 17% in one day. Market rotation began.'
    },
    significance: 'high'
  },
  {
    id: '17',
    date: '2025-03-14',
    title: 'Lunar Eclipse in Virgo',
    description: 'Total lunar eclipse in Virgo, culmination of health, work, and service themes.',
    planets: ['Sun', 'Moon'],
    aspect: 'Opposition (Eclipse)',
    marketImpact: {
      sp500Change: -1.39,
      nasdaqChange: -2.00,
      dowChange: -1.30,
      summary: 'Tariff concerns weighed heavily. Recession fears mounted. Tech stocks led decline.'
    },
    significance: 'medium'
  },
  {
    id: '18',
    date: '2025-03-30',
    title: 'Neptune enters Aries',
    description: 'Neptune enters Aries for a 14-year stay, beginning a new spiritual and idealistic cycle.',
    planets: ['Neptune'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: 1.80,
      nasdaqChange: 2.20,
      dowChange: 1.60,
      summary: 'Quarter-end rally. Tariff concerns eased slightly. Tech stocks bounced back.'
    },
    significance: 'high'
  },
  {
    id: '19',
    date: '2025-05-24',
    title: 'Saturn enters Aries',
    description: 'Saturn enters Aries, bringing discipline and structure to new beginnings.',
    planets: ['Saturn'],
    aspect: 'Ingress',
    marketImpact: {
      sp500Change: 0.00,
      nasdaqChange: 0.00,
      dowChange: 0.00,
      summary: 'Upcoming event - Markets may experience increased volatility as Saturn brings restriction to Aries energy.'
    },
    significance: 'high'
  },
  {
    id: '20',
    date: '2025-06-09',
    title: 'Jupiter conjunct Mercury in Cancer',
    description: 'Jupiter and Mercury conjunct in Cancer, expansive thinking about security and home.',
    planets: ['Jupiter', 'Mercury'],
    aspect: 'Conjunction',
    marketImpact: {
      sp500Change: 0.00,
      nasdaqChange: 0.00,
      dowChange: 0.00,
      summary: 'Upcoming event - Potential for significant market news or announcements affecting housing/finance.'
    },
    significance: 'medium'
  }
];

export function getUpcomingEvents(): AstroEvent[] {
  const today = new Date();
  return majorAstroEvents.filter(event => new Date(event.date) >= today);
}

export function getPastEvents(): AstroEvent[] {
  const today = new Date();
  return majorAstroEvents
    .filter(event => new Date(event.date) < today)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export function getHighSignificanceEvents(): AstroEvent[] {
  return majorAstroEvents.filter(event => event.significance === 'high');
}
