import { useMemo } from 'react';
import { ZODIAC_SIGNS, formatDegree, ASPECT_COLORS } from '@/types/astro';
import type { Planet, House, Aspect } from '@/types/astro';

interface LinearAstroChartProps {
  planets: Planet[];
  houses: House[];
  aspects?: Aspect[];
  width?: number;
  height?: number;
}

const CHART_PADDING = 60;
const SIGN_HEIGHT = 50;

export const LinearAstroChart: React.FC<LinearAstroChartProps> = ({
  planets,
  houses,
  aspects = [],
  width = 1200,
  height = 400,
}) => {
  const chartWidth = width - CHART_PADDING * 2;
  const degreeToX = (degree: number) => {
    const normalizedDegree = ((degree % 360) + 360) % 360;
    return CHART_PADDING + (normalizedDegree / 360) * chartWidth;
  };

  const sortedPlanets = useMemo(() => {
    return [...planets].sort((a, b) => {
      const normalizedA = ((a.degree % 360) + 360) % 360;
      const normalizedB = ((b.degree % 360) + 360) % 360;
      return normalizedA - normalizedB;
    });
  }, [planets]);

  const planetPositions = useMemo(() => {
    const positions: Record<string, { x: number; y: number; lane: number }> = {};
    const lanes: { start: number; end: number }[] = [];

    sortedPlanets.forEach((planet) => {
      const x = degreeToX(planet.degree);
      let lane = 0;
      let placed = false;

      while (!placed) {
        const laneStart = x - 25;
        const laneEnd = x + 25;
        const laneOccupied = lanes.some(
          (l, idx) => idx === lane && !(laneEnd < l.start || laneStart > l.end)
        );

        if (!laneOccupied) {
          if (!lanes[lane]) lanes[lane] = { start: laneStart, end: laneEnd };
          else {
            lanes[lane].start = Math.min(lanes[lane].start, laneStart);
            lanes[lane].end = Math.max(lanes[lane].end, laneEnd);
          }
          positions[planet.id] = { x, y: 180 + lane * 45, lane };
          placed = true;
        } else {
          lane++;
        }
      }
    });

    return positions;
  }, [sortedPlanets]);

  const aspectLines = useMemo(() => {
    return aspects.map((aspect) => {
      const p1 = planetPositions[aspect.planet1];
      const p2 = planetPositions[aspect.planet2];
      if (!p1 || !p2) return null;

      return {
        ...aspect,
        x1: p1.x,
        y1: p1.y,
        x2: p2.x,
        y2: p2.y,
      };
    }).filter(Boolean);
  }, [aspects, planetPositions]);

  return (
    <svg width={width} height={height} className="astro-chart">
      <defs>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <linearGradient id="signGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="rgba(30, 30, 40, 0.8)" />
          <stop offset="100%" stopColor="rgba(20, 20, 30, 0.95)" />
        </linearGradient>
      </defs>

      {/* Background */}
      <rect width={width} height={height} fill="transparent" />

      {/* Zodiac Sign Bands */}
      {ZODIAC_SIGNS.map((sign) => {
        const x1 = degreeToX(sign.startDegree);
        const x2 = degreeToX(sign.endDegree);
        const segmentWidth = x2 - x1;

        return (
          <g key={sign.id}>
            {/* Sign background */}
            <rect
              x={x1}
              y={80}
              width={segmentWidth}
              height={SIGN_HEIGHT}
              fill={`${sign.color}15`}
              stroke={sign.color}
              strokeWidth={1}
              opacity={0.6}
            />
            
            {/* Sign symbol */}
            <text
              x={x1 + segmentWidth / 2}
              y={112}
              textAnchor="middle"
              fill={sign.color}
              fontSize={20}
              fontWeight="500"
              filter="url(#glow)"
            >
              {sign.symbol}
            </text>

            {/* Sign name */}
            <text
              x={x1 + segmentWidth / 2}
              y={130}
              textAnchor="middle"
              fill={sign.color}
              fontSize={10}
              opacity={0.8}
            >
              {sign.name}
            </text>

            {/* Degree markers */}
            {[0, 10, 20, 30].map((deg) => {
              const markerX = degreeToX(sign.startDegree + deg);
              return (
                <line
                  key={deg}
                  x1={markerX}
                  y1={80}
                  x2={markerX}
                  y2={85}
                  stroke={sign.color}
                  strokeWidth={1}
                  opacity={0.5}
                />
              );
            })}
          </g>
        );
      })}

      {/* House Cusps */}
      {houses.map((house) => {
        const x = degreeToX(house.cuspDegree);
        return (
          <g key={house.number}>
            <line
              x1={x}
              y1={55}
              x2={x}
              y2={140}
              stroke="#6366f1"
              strokeWidth={house.number === 1 || house.number === 10 ? 2 : 1}
              opacity={0.7}
              strokeDasharray={house.number === 1 || house.number === 10 ? undefined : '4,4'}
            />
            <text
              x={x}
              y={50}
              textAnchor="middle"
              fill="#6366f1"
              fontSize={11}
              fontWeight={house.number === 1 || house.number === 10 ? '600' : '400'}
            >
              {house.number === 1 ? 'ASC' : house.number === 10 ? 'MC' : `H${house.number}`}
            </text>
          </g>
        );
      })}

      {/* Aspect Lines */}
      {aspectLines.map((aspect, idx) => (
        <line
          key={idx}
          x1={aspect!.x1}
          y1={aspect!.y1}
          x2={aspect!.x2}
          y2={aspect!.y2}
          stroke={ASPECT_COLORS[aspect!.type]}
          strokeWidth={1.5}
          opacity={0.4}
          strokeDasharray={aspect!.type === 'square' || aspect!.type === 'opposition' ? undefined : '3,3'}
        />
      ))}

      {/* Planets */}
      {sortedPlanets.map((planet) => {
        const pos = planetPositions[planet.id];
        if (!pos) return null;

        return (
          <g key={planet.id}>
            {/* Connection line to zodiac band */}
            <line
              x1={pos.x}
              y1={pos.y - 20}
              x2={pos.x}
              y2={130}
              stroke={planet.color}
              strokeWidth={1}
              opacity={0.3}
            />

            {/* Planet circle */}
            <circle
              cx={pos.x}
              cy={pos.y}
              r={18}
              fill="#0f0f15"
              stroke={planet.color}
              strokeWidth={2}
              filter="url(#glow)"
            />

            {/* Planet symbol */}
            <text
              x={pos.x}
              y={pos.y + 6}
              textAnchor="middle"
              fill={planet.color}
              fontSize={16}
              fontWeight="500"
            >
              {planet.symbol}
            </text>

            {/* Retrograde indicator */}
            {planet.retrograde && (
              <text
                x={pos.x + 12}
                y={pos.y - 8}
                textAnchor="middle"
                fill="#ef4444"
                fontSize={10}
                fontWeight="bold"
              >
                ℞
              </text>
            )}

            {/* Degree tooltip */}
            <g transform={`translate(${pos.x}, ${pos.y + 35})`}>
              <rect
                x={-35}
                y={-10}
                width={70}
                height={18}
                rx={4}
                fill="#1a1a25"
                stroke={planet.color}
                strokeWidth={1}
                opacity={0.9}
              />
              <text
                x={0}
                y={3}
                textAnchor="middle"
                fill="#e2e8f0"
                fontSize={9}
              >
                {formatDegree(planet.degree)}
              </text>
            </g>
          </g>
        );
      })}

      {/* Degree scale */}
      {Array.from({ length: 13 }, (_, i) => i * 30).map((deg) => (
        <g key={deg}>
          <line
            x1={degreeToX(deg)}
            y1={145}
            x2={degreeToX(deg)}
            y2={150}
            stroke="#475569"
            strokeWidth={1}
          />
          <text
            x={degreeToX(deg)}
            y={165}
            textAnchor="middle"
            fill="#64748b"
            fontSize={10}
          >
            {deg}°
          </text>
        </g>
      ))}
    </svg>
  );
};

export default LinearAstroChart;
