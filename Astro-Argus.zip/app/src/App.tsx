import { useState, useEffect } from 'react';
import { LinearAstroChart } from '@/components/LinearAstroChart';
import { generateLiveChartData } from '@/data/livePositions';
import { ZODIAC_SIGNS, formatDegree } from '@/types/astro';
import type { Planet, House, Aspect } from '@/types/astro';
import { RefreshCw, ChevronDown, ChevronUp, Sparkles, AlertTriangle, Calendar, Activity } from 'lucide-react';
import { getPastEvents } from '@/data/astroEvents';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import './App.css';

// Categorize planets as positive (benefic) or negative (malefic)
const POSITIVE_PLANETS = ['sun', 'moon', 'venus', 'jupiter'];
const NEGATIVE_PLANETS = ['mars', 'saturn'];

// Categorize aspects as positive or negative
const POSITIVE_ASPECTS = ['conjunction', 'sextile', 'trine'];
const NEGATIVE_ASPECTS = ['square', 'opposition'];

function App() {
  // Initialize with live data
  const initialData = generateLiveChartData();
  const [planets, setPlanets] = useState<Planet[]>(initialData.planets);
  const [houses, setHouses] = useState<House[]>(initialData.houses);
  const [aspects, setAspects] = useState<Aspect[]>(initialData.aspects);
  const [showAspects, setShowAspects] = useState(true);
  const [showHouses, setShowHouses] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [expandedSection, setExpandedSection] = useState<string | null>('planets');
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Auto-refresh planetary positions every minute
  useEffect(() => {
    if (!autoRefresh) return;
    
    const refreshTimer = setInterval(() => {
      refreshData();
    }, 60000); // Refresh every minute
    
    return () => clearInterval(refreshTimer);
  }, [autoRefresh]);

  const refreshData = () => {
    const newData = generateLiveChartData();
    setPlanets(newData.planets);
    setHouses(newData.houses);
    setAspects(newData.aspects);
    setLastUpdated(new Date());
  };

  const handleRefresh = () => {
    refreshData();
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const displayedAspects = showAspects ? aspects : [];

  // Filter planets by positive/negative
  const positivePlanets = planets.filter(p => POSITIVE_PLANETS.includes(p.id));
  const negativePlanets = planets.filter(p => NEGATIVE_PLANETS.includes(p.id));
  const neutralPlanets = planets.filter(p => 
    !POSITIVE_PLANETS.includes(p.id) && !NEGATIVE_PLANETS.includes(p.id)
  );

  // Filter aspects by positive/negative
  const positiveAspects = aspects.filter(a => POSITIVE_ASPECTS.includes(a.type));
  const negativeAspects = aspects.filter(a => NEGATIVE_ASPECTS.includes(a.type));

  // Filter retrogrades by positive/negative
  const positiveRetrogrades = planets.filter(p => 
    p.retrograde && POSITIVE_PLANETS.includes(p.id)
  );
  const negativeRetrogrades = planets.filter(p => 
    p.retrograde && NEGATIVE_PLANETS.includes(p.id)
  );
  const neutralRetrogrades = planets.filter(p => 
    p.retrograde && !POSITIVE_PLANETS.includes(p.id) && !NEGATIVE_PLANETS.includes(p.id)
  );

  const renderPlanetCard = (planet: Planet) => {
    const sign = ZODIAC_SIGNS[Math.floor(((planet.degree % 360) + 360) % 360 / 30)];
    return (
      <div
        key={planet.id}
        className="p-3 rounded-lg bg-slate-800/30 border border-slate-700/30 hover:border-slate-600/50 transition-colors"
      >
        <div className="flex items-center gap-2 mb-2">
          <span
            className="w-6 h-6 rounded-full flex items-center justify-center text-sm"
            style={{ backgroundColor: `${planet.color}20`, color: planet.color }}
          >
            {planet.symbol}
          </span>
          <span className="text-sm font-medium text-slate-300 capitalize">
            {planet.name}
          </span>
          {planet.retrograde && (
            <span className="text-xs text-red-400 font-bold">℞</span>
          )}
        </div>
        <div className="text-xs text-slate-500">
          <span style={{ color: sign.color }}>{sign.symbol}</span>
          {' '}{formatDegree(planet.degree)}
        </div>
      </div>
    );
  };

  const getPlanetInfo = (planetId: string) => {
    return planets.find(p => p.id === planetId) || { symbol: '●', name: planetId, color: '#94a3b8' };
  };

  const renderAspectBadge = (aspect: Aspect) => {
    const aspectColors: Record<string, string> = {
      conjunction: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      sextile: 'bg-green-500/20 text-green-400 border-green-500/30',
      trine: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      square: 'bg-red-500/20 text-red-400 border-red-500/30',
      opposition: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    };

    const planet1 = getPlanetInfo(aspect.planet1);
    const planet2 = getPlanetInfo(aspect.planet2);

    return (
      <div
        key={`${aspect.planet1}-${aspect.planet2}-${aspect.type}`}
        className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg border ${aspectColors[aspect.type]}`}
      >
        {/* Planet 1 */}
        <div className="flex items-center gap-1">
          <span style={{ color: planet1.color }}>{planet1.symbol}</span>
          <span className="text-xs capitalize">{planet1.name}</span>
        </div>
        
        {/* Aspect symbol */}
        <span className="text-xs opacity-50 mx-1">
          {aspect.type === 'conjunction' && '☌'}
          {aspect.type === 'sextile' && '⚹'}
          {aspect.type === 'square' && '□'}
          {aspect.type === 'trine' && '△'}
          {aspect.type === 'opposition' && '☍'}
        </span>
        
        {/* Planet 2 */}
        <div className="flex items-center gap-1">
          <span style={{ color: planet2.color }}>{planet2.symbol}</span>
          <span className="text-xs capitalize">{planet2.name}</span>
        </div>
        
        {/* Orb */}
        <span className="text-xs opacity-60 ml-1">({aspect.orb.toFixed(1)}°)</span>
      </div>
    );
  };

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-[#0a0a0f] text-slate-200">
        {/* Header */}
        <header className="border-b border-slate-800/50 bg-[#0f0f15]/80 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 relative">
                  <span className="text-xl">✦</span>
                  {/* Live indicator pulse */}
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse border-2 border-[#0f0f15]"></span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-xl font-semibold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                      Linear Astro Chart
                    </h1>
                    <span className="px-1.5 py-0.5 text-[10px] bg-green-500/20 text-green-400 rounded border border-green-500/30 flex items-center gap-1">
                      <Activity className="w-3 h-3" />
                      LIVE
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {currentTime.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                    {' • '}
                    <span className="text-slate-400">
                      Updated: {lastUpdated.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {/* Auto-refresh toggle */}
                <div className="flex items-center gap-2 mr-2">
                  <Switch
                    id="autorefresh"
                    checked={autoRefresh}
                    onCheckedChange={setAutoRefresh}
                    className="data-[state=checked]:bg-green-500"
                  />
                  <label htmlFor="autorefresh" className="text-xs text-slate-400 cursor-pointer">
                    Auto
                  </label>
                </div>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleRefresh}
                      className="text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Refresh positions</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Chart Container */}
          <Card className="bg-[#13131a] border-slate-800/50 mb-8 overflow-hidden">
            <CardHeader className="border-b border-slate-800/50 pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-slate-200">
                  Natal Chart Visualization
                </CardTitle>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="aspects"
                      checked={showAspects}
                      onCheckedChange={setShowAspects}
                      className="data-[state=checked]:bg-indigo-500"
                    />
                    <label htmlFor="aspects" className="text-sm text-slate-400 cursor-pointer">
                      Aspects
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="houses"
                      checked={showHouses}
                      onCheckedChange={setShowHouses}
                      className="data-[state=checked]:bg-indigo-500"
                    />
                    <label htmlFor="houses" className="text-sm text-slate-400 cursor-pointer">
                      Houses
                    </label>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="overflow-x-auto">
                <LinearAstroChart
                  planets={planets}
                  houses={showHouses ? houses : []}
                  aspects={displayedAspects}
                  width={1200}
                  height={380}
                />
              </div>
            </CardContent>
          </Card>

          {/* Stats Grid - Aspects */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Positive Aspects */}
            <Card className="bg-[#13131a] border-slate-800/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-green-400" />
                  <CardTitle className="text-sm font-medium text-green-400">Positive Aspects</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {positiveAspects.length > 0 ? (
                  <div className="flex flex-wrap gap-3">
                    {positiveAspects.map(renderAspectBadge)}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">No positive aspects</p>
                )}
              </CardContent>
            </Card>

            {/* Negative Aspects */}
            <Card className="bg-[#13131a] border-slate-800/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <CardTitle className="text-sm font-medium text-red-400">Negative Aspects</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {negativeAspects.length > 0 ? (
                  <div className="flex flex-wrap gap-3">
                    {negativeAspects.map(renderAspectBadge)}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">No negative aspects</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Planet Positions - Positive & Negative */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Positive Planets */}
            <Card className="bg-[#13131a] border-slate-800/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-green-400" />
                  <CardTitle className="text-sm font-medium text-green-400">Positive Planets</CardTitle>
                </div>
                <p className="text-xs text-slate-500 mt-1">Benefic: Sun, Moon, Venus, Jupiter</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
                  {positivePlanets.map(renderPlanetCard)}
                </div>
              </CardContent>
            </Card>

            {/* Negative Planets */}
            <Card className="bg-[#13131a] border-slate-800/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <CardTitle className="text-sm font-medium text-red-400">Negative Planets</CardTitle>
                </div>
                <p className="text-xs text-slate-500 mt-1">Malefic: Mars, Saturn</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
                  {negativePlanets.map(renderPlanetCard)}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Retrogrades - Positive & Negative */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Positive Retrogrades */}
            <Card className="bg-[#13131a] border-slate-800/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-yellow-400" />
                  <CardTitle className="text-sm font-medium text-yellow-400">Positive Retrogrades</CardTitle>
                </div>
                <p className="text-xs text-slate-500 mt-1">Benefic planets in retrograde</p>
              </CardHeader>
              <CardContent>
                {positiveRetrogrades.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
                    {positiveRetrogrades.map(renderPlanetCard)}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">No positive retrogrades</p>
                )}
              </CardContent>
            </Card>

            {/* Negative Retrogrades */}
            <Card className="bg-[#13131a] border-slate-800/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-orange-400" />
                  <CardTitle className="text-sm font-medium text-orange-400">Negative Retrogrades</CardTitle>
                </div>
                <p className="text-xs text-slate-500 mt-1">Malefic planets in retrograde</p>
              </CardHeader>
              <CardContent>
                {negativeRetrogrades.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
                    {negativeRetrogrades.map(renderPlanetCard)}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">No negative retrogrades</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Neutral Planets & Retrogrades */}
          {(neutralPlanets.length > 0 || neutralRetrogrades.length > 0) && (
            <Card className="bg-[#13131a] border-slate-800/50 mb-8">
              <CardHeader 
                className="pb-3 cursor-pointer hover:bg-slate-800/30 transition-colors"
                onClick={() => toggleSection('neutral')}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-sm font-medium text-slate-400">Neutral Planets</CardTitle>
                    <p className="text-xs text-slate-500 mt-1">Mercury, Uranus, Neptune, Pluto, Nodes, Points</p>
                  </div>
                  {expandedSection === 'neutral' ? (
                    <ChevronUp className="w-4 h-4 text-slate-500" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-500" />
                  )}
                </div>
              </CardHeader>
              {expandedSection === 'neutral' && (
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    {neutralPlanets.map(renderPlanetCard)}
                  </div>
                </CardContent>
              )}
            </Card>
          )}

          {/* Major Astrological Events & Market Impact */}
          <Card className="bg-[#13131a] border-slate-800/50 mb-8">
            <CardHeader 
              className="pb-3 cursor-pointer hover:bg-slate-800/30 transition-colors"
              onClick={() => toggleSection('events')}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                    <Calendar className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-medium text-slate-200">Major Astrological Events & Market Impact</CardTitle>
                    <p className="text-xs text-slate-500 mt-1">Historical correlation between planetary events and stock market movements</p>
                  </div>
                </div>
                {expandedSection === 'events' ? (
                  <ChevronUp className="w-4 h-4 text-slate-500" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-500" />
                )}
              </div>
            </CardHeader>
            {expandedSection === 'events' && (
              <CardContent>
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                  {getPastEvents().map((event) => (
                    <div
                      key={event.id}
                      className={`p-4 rounded-lg border ${
                        event.significance === 'high' 
                          ? 'bg-amber-500/5 border-amber-500/20' 
                          : 'bg-slate-800/30 border-slate-700/30'
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                        {/* Date and Title */}
                        <div className="lg:w-1/4">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-mono text-slate-400">{event.date}</span>
                            {event.significance === 'high' && (
                              <span className="px-1.5 py-0.5 text-[10px] bg-amber-500/20 text-amber-400 rounded">HIGH</span>
                            )}
                          </div>
                          <h4 className="text-sm font-medium text-slate-200">{event.title}</h4>
                          <div className="flex items-center gap-2 mt-2">
                            {event.planets.map((planet) => {
                              const planetInfo = getPlanetInfo(planet.toLowerCase());
                              return (
                                <span key={planet} className="text-sm" style={{ color: planetInfo.color }}>
                                  {planetInfo.symbol}
                                </span>
                              );
                            })}
                            <span className="text-xs text-slate-500">{event.aspect}</span>
                          </div>
                        </div>

                        {/* Description */}
                        <div className="lg:w-1/3">
                          <p className="text-xs text-slate-400 leading-relaxed">{event.description}</p>
                        </div>

                        {/* Market Impact */}
                        <div className="lg:w-5/12">
                          <div className="grid grid-cols-3 gap-2 mb-2">
                            <div className={`text-center p-2 rounded ${
                              event.marketImpact.sp500Change >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'
                            }`}>
                              <div className="text-[10px] text-slate-500 mb-0.5">S&P 500</div>
                              <div className={`text-sm font-medium ${
                                event.marketImpact.sp500Change >= 0 ? 'text-green-400' : 'text-red-400'
                              }`}>
                                {event.marketImpact.sp500Change >= 0 ? '+' : ''}{event.marketImpact.sp500Change.toFixed(2)}%
                              </div>
                            </div>
                            <div className={`text-center p-2 rounded ${
                              event.marketImpact.nasdaqChange >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'
                            }`}>
                              <div className="text-[10px] text-slate-500 mb-0.5">NASDAQ</div>
                              <div className={`text-sm font-medium ${
                                event.marketImpact.nasdaqChange >= 0 ? 'text-green-400' : 'text-red-400'
                              }`}>
                                {event.marketImpact.nasdaqChange >= 0 ? '+' : ''}{event.marketImpact.nasdaqChange.toFixed(2)}%
                              </div>
                            </div>
                            <div className={`text-center p-2 rounded ${
                              event.marketImpact.dowChange >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'
                            }`}>
                              <div className="text-[10px] text-slate-500 mb-0.5">DOW</div>
                              <div className={`text-sm font-medium ${
                                event.marketImpact.dowChange >= 0 ? 'text-green-400' : 'text-red-400'
                              }`}>
                                {event.marketImpact.dowChange >= 0 ? '+' : ''}{event.marketImpact.dowChange.toFixed(2)}%
                              </div>
                            </div>
                          </div>
                          <p className="text-xs text-slate-500 leading-relaxed">{event.marketImpact.summary}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            )}
          </Card>

          {/* Legend */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-400/80" />
              <span>Conjunction</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500/80" />
              <span>Sextile</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500/80" />
              <span>Trine</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/80" />
              <span>Square</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500/80" />
              <span>Opposition</span>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-800/50 mt-12 py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-slate-600">
            <p>Linear Astro Chart • A modern approach to astrological visualization</p>
          </div>
        </footer>
      </div>
    </TooltipProvider>
  );
}

export default App;
