export interface ZodiacSign {
  id: number;
  name: string;
  symbol: string;
  element: 'fire' | 'earth' | 'air' | 'water';
  modality: 'cardinal' | 'fixed' | 'mutable';
  startDegree: number;
  endDegree: number;
  color: string;
}

export interface Planet {
  id: string;
  name: string;
  symbol: string;
  degree: number;
  sign: number;
  signDegree: number;
  retrograde?: boolean;
  color: string;
}

export interface House {
  number: number;
  cuspDegree: number;
  sign: number;
}

export interface Aspect {
  planet1: string;
  planet2: string;
  type: 'conjunction' | 'sextile' | 'square' | 'trine' | 'opposition';
  orb: number;
  angle: number;
}

export const ZODIAC_SIGNS: ZodiacSign[] = [
  { id: 0, name: 'Aries', symbol: '♈', element: 'fire', modality: 'cardinal', startDegree: 0, endDegree: 30, color: '#ef4444' },
  { id: 1, name: 'Taurus', symbol: '♉', element: 'earth', modality: 'fixed', startDegree: 30, endDegree: 60, color: '#22c55e' },
  { id: 2, name: 'Gemini', symbol: '♊', element: 'air', modality: 'mutable', startDegree: 60, endDegree: 90, color: '#eab308' },
  { id: 3, name: 'Cancer', symbol: '♋', element: 'water', modality: 'cardinal', startDegree: 90, endDegree: 120, color: '#64748b' },
  { id: 4, name: 'Leo', symbol: '♌', element: 'fire', modality: 'fixed', startDegree: 120, endDegree: 150, color: '#ef4444' },
  { id: 5, name: 'Virgo', symbol: '♍', element: 'earth', modality: 'mutable', startDegree: 150, endDegree: 180, color: '#22c55e' },
  { id: 6, name: 'Libra', symbol: '♎', element: 'air', modality: 'cardinal', startDegree: 180, endDegree: 210, color: '#eab308' },
  { id: 7, name: 'Scorpio', symbol: '♏', element: 'water', modality: 'fixed', startDegree: 210, endDegree: 240, color: '#64748b' },
  { id: 8, name: 'Sagittarius', symbol: '♐', element: 'fire', modality: 'mutable', startDegree: 240, endDegree: 270, color: '#ef4444' },
  { id: 9, name: 'Capricorn', symbol: '♑', element: 'earth', modality: 'cardinal', startDegree: 270, endDegree: 300, color: '#22c55e' },
  { id: 10, name: 'Aquarius', symbol: '♒', element: 'air', modality: 'fixed', startDegree: 300, endDegree: 330, color: '#eab308' },
  { id: 11, name: 'Pisces', symbol: '♓', element: 'water', modality: 'mutable', startDegree: 330, endDegree: 360, color: '#64748b' },
];

export const PLANET_SYMBOLS: Record<string, string> = {
  sun: '☉',
  moon: '☽',
  mercury: '☿',
  venus: '♀',
  mars: '♂',
  jupiter: '♃',
  saturn: '♄',
  uranus: '♅',
  neptune: '♆',
  pluto: '♇',
  northNode: '☊',
  southNode: '☋',
  ascendant: 'ASC',
  mc: 'MC',
};

export const ASPECT_COLORS: Record<string, string> = {
  conjunction: '#fbbf24',
  sextile: '#22c55e',
  square: '#ef4444',
  trine: '#3b82f6',
  opposition: '#a855f7',
};

export function getSignByDegree(degree: number): ZodiacSign {
  const normalizedDegree = ((degree % 360) + 360) % 360;
  const signIndex = Math.floor(normalizedDegree / 30);
  return ZODIAC_SIGNS[signIndex];
}

export function formatDegree(degree: number): string {
  const normalizedDegree = ((degree % 360) + 360) % 360;
  const sign = getSignByDegree(normalizedDegree);
  const signDegree = normalizedDegree - sign.startDegree;
  const degrees = Math.floor(signDegree);
  const minutes = Math.floor((signDegree - degrees) * 60);
  return `${degrees}°${minutes.toString().padStart(2, '0')}' ${sign.symbol}`;
}
